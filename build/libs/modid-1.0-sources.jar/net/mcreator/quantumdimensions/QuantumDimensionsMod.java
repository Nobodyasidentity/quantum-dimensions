package net.mcreator.quantumdimensions;

import org.jetbrains.annotations.Nullable;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import net.mcreator.quantumdimensions.init.*;
import net.minecraft.class_1657;
import net.minecraft.class_3545;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.api.EnvType;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;

import java.lang.invoke.MethodType;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandle;

public class QuantumDimensionsMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger(QuantumDimensionsMod.class);
	public static final String MODID = "quantum_dimensions";

	@Override
	public void onInitialize() {
		// Start of user code block mod constructor
		// End of user code block mod constructor
		LOGGER.info("Initializing QuantumDimensionsMod");
		QuantumDimensionsModTabs.load();
		QuantumDimensionsModBlocks.load();
		QuantumDimensionsModBlockEntities.load();
		QuantumDimensionsModItems.load();
		QuantumDimensionsModDimensions.load();
		QuantumDimensionsModMenus.load();
		tick();
		// Start of user code block mod init
		// End of user code block mod init
	}

	// Start of user code block mod methods
	// End of user code block mod methods
	private static final Collection<class_3545<Runnable, Integer>> workQueue = new ConcurrentLinkedQueue<>();

	public static void queueServerWork(int tick, Runnable action) {
		workQueue.add(new class_3545<>(action, tick));
	}

	private void tick() {
		ServerTickEvents.END_SERVER_TICK.register((server) -> {
			List<class_3545<Runnable, Integer>> actions = new ArrayList<>();
			workQueue.forEach(work -> {
				work.method_34965(work.method_15441() - 1);
				if (work.method_15441() == 0)
					actions.add(work);
			});
			actions.forEach(e -> e.method_15442().run());
			workQueue.removeAll(actions);
		});
	}

	private static Object minecraft;
	private static MethodHandle playerHandle;

	@Nullable
	public static class_1657 clientPlayer() {
		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			try {
				if (minecraft == null || playerHandle == null) {
					Class<?> minecraftClass = Class.forName("net.minecraft.client.Minecraft");
					minecraft = MethodHandles.publicLookup().findStatic(minecraftClass, "getInstance", MethodType.methodType(minecraftClass)).invoke();
					playerHandle = MethodHandles.publicLookup().findGetter(minecraftClass, "player", Class.forName("net.minecraft.client.player.LocalPlayer"));
				}
				return (class_1657) playerHandle.invoke(minecraft);
			} catch (Throwable e) {
				LOGGER.error("Failed to get client player", e);
				return null;
			}
		} else {
			return null;
		}
	}
}
package net.mcreator.quantumdimensions.item;

import net.mcreator.quantumdimensions.procedures.RebreatherAdvancementProcedure;
import net.minecraft.class_10192;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.mcreator.quantumdimensions.QuantumDimensionsMod;

public class RebreatherItem extends class_1792 {
    public RebreatherItem(class_1792.class_1793 properties) {
        super(properties.method_7889(1)
                .method_57349(class_9334.field_54196,
                        class_10192.method_64202(class_1304.field_6169)
                                .method_65009(class_2960.method_60655(QuantumDimensionsMod.MODID, "misc/rebreatherblur"))
                                .method_64203()).method_57348(class_9285.method_57480().method_57487(
                                class_5134.field_51583,
                                new class_1322(class_2960.method_60655(QuantumDimensionsMod.MODID, "rebreather_oxygen"), 20, class_1322.class_1323.field_6328),
                                class_9274.field_49223
                        ).method_57486()));
    }
	@Override
	public void method_54465(class_1799 itemstack, class_1657 entity) {
		super.method_54465(itemstack, entity);
		RebreatherAdvancementProcedure.execute(entity);
	}
}
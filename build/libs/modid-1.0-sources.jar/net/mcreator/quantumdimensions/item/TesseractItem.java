package net.mcreator.quantumdimensions.item;

import net.minecraft.class_1792;
import net.minecraft.class_1814;

public class TesseractItem extends class_1792 {
	public TesseractItem(class_1792.class_1793 properties) {
		super(properties.method_7894(class_1814.field_8904).method_7889(1).method_24359());
	}
}
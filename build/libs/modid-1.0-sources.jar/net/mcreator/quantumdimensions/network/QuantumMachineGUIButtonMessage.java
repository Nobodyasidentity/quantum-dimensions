package net.mcreator.quantumdimensions.network;

import net.mcreator.quantumdimensions.procedures.QuantumMachineProcedureProcedure;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_4076;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.mcreator.quantumdimensions.QuantumDimensionsMod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public record QuantumMachineGUIButtonMessage(int buttonID, int x, int y, int z) implements class_8710 {
	public static final class_9154<QuantumMachineGUIButtonMessage> TYPE = new class_9154<>(class_2960.method_60655(QuantumDimensionsMod.MODID, "quantum_machine_gui_buttons"));
	public static final class_9139<class_9129, QuantumMachineGUIButtonMessage> STREAM_CODEC = class_9139.method_56437((class_9129 buffer, QuantumMachineGUIButtonMessage message) -> {
		buffer.method_53002(message.buttonID);
		buffer.method_53002(message.x);
		buffer.method_53002(message.y);
		buffer.method_53002(message.z);
	}, (class_9129 buffer) -> new QuantumMachineGUIButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));

	@Override
	public class_9154<QuantumMachineGUIButtonMessage> method_56479() {
		return TYPE;
	}

	public static void handleData(final QuantumMachineGUIButtonMessage message, final ServerPlayNetworking.Context context) {
		context.server().execute(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z));
	}

	public static void handleButtonAction(class_1657 entity, int buttonID, int x, int y, int z) {
		class_1937 world = entity.method_37908();
		// security measure to prevent arbitrary chunk generation
		if (!world.method_8398().method_12123(class_4076.method_18675(x), class_4076.method_18675(z)))
			return;
		if (buttonID == 0) {

			QuantumMachineProcedureProcedure.execute(world, x, y, z, entity);
		}
	}
}
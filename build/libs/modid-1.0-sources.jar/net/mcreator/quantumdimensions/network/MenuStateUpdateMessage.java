package net.mcreator.quantumdimensions.network;

import net.mcreator.quantumdimensions.init.QuantumDimensionsModScreens;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.mcreator.quantumdimensions.init.QuantumDimensionsModMenus;
import net.mcreator.quantumdimensions.QuantumDimensionsMod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public record MenuStateUpdateMessage(int elementType, String name, Object elementState) implements class_8710 {
	public static final class_9154<MenuStateUpdateMessage> TYPE = new class_9154<>(class_2960.method_60655(QuantumDimensionsMod.MODID, "menustate_update"));
	public static final class_9139<class_9129, MenuStateUpdateMessage> STREAM_CODEC = class_9139.method_56437(MenuStateUpdateMessage::write, MenuStateUpdateMessage::read);

	public static void write(class_2540 buffer, MenuStateUpdateMessage message) {
		buffer.method_53002(message.elementType);
		buffer.method_10814(message.name);
		if (message.elementType == 0) {
			buffer.method_10814((String) message.elementState);
		} else if (message.elementType == 1) {
			buffer.method_52964((boolean) message.elementState);
		} else if (message.elementType == 2 && message.elementState instanceof Number n) {
			buffer.method_52940(n.doubleValue());
		}
	}

	public static MenuStateUpdateMessage read(class_2540 buffer) {
		int elementType = buffer.readInt();
		String name = buffer.method_19772();
		Object elementState = null;
		if (elementType == 0) {
			elementState = buffer.method_19772();
		} else if (elementType == 1) {
			elementState = buffer.readBoolean();
		} else if (elementType == 2) {
			elementState = buffer.readDouble();
		}
		return new MenuStateUpdateMessage(elementType, name, elementState);
	}

	@Override
	public class_9154<MenuStateUpdateMessage> method_56479() {
		return TYPE;
	}

	public static void handleMenuState(final MenuStateUpdateMessage message, final ServerPlayNetworking.Context context) {
		if (message.name.length() > 256 || message.elementState instanceof String string && string.length() > 8192)
			return;
		context.server().execute(() -> {
			if (context.player().field_7512 instanceof QuantumDimensionsModMenus.MenuAccessor menu) {
				menu.getMenuState().put(message.elementType + ":" + message.name, message.elementState);
				if (class_310.method_1551().field_1755 instanceof QuantumDimensionsModScreens.FabricScreenAccessor accessor) {
					accessor.updateMenuState(message.elementType, message.name, message.elementState);
				}
			}
		});
	}

	public static void handleClientMenuState(final MenuStateUpdateMessage message, final ClientPlayNetworking.Context context) {
		if (message.name.length() > 256 || message.elementState instanceof String string && string.length() > 8192)
			return;
		context.client().execute(() -> {
			if (context.player().field_7512 instanceof QuantumDimensionsModMenus.MenuAccessor menu) {
				menu.getMenuState().put(message.elementType + ":" + message.name, message.elementState);
				if (class_310.method_1551().field_1755 instanceof QuantumDimensionsModScreens.FabricScreenAccessor accessor) {
					accessor.updateMenuState(message.elementType, message.name, message.elementState);
				}
			}
		});
	}
}
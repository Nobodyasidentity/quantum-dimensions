package net.mcreator.quantumdimensions.procedures;

import net.minecraft.class_1297;
import net.minecraft.class_167;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8779;

public class RebreatherAdvancementProcedure {
	public static boolean eventResult = true;

	public static void execute(class_1297 entity) {
		if (entity == null)
			return;
		if ((entity.method_37908().method_27983()) == class_5321.method_29179(class_7924.field_41223, class_2960.method_60654("quantum_dimensions:the_27th_dimension"))) {
			if (entity instanceof class_3222 _player && _player.method_51469() instanceof class_3218 _level) {
				class_8779 _adv3 = _level.method_8503().method_3851().method_12896(class_2960.method_60654("quantum_dimensions:get_rebreather"));
				if (_adv3 != null) {
					class_167 _ap = _player.method_14236().method_12882(_adv3);
					if (!_ap.method_740()) {
						for (String criteria : _ap.method_731())
							_player.method_14236().method_12878(_adv3, criteria);
					}
				}
			}
		}
	}
}
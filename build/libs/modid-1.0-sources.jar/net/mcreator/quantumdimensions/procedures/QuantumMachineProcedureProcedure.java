package net.mcreator.quantumdimensions.procedures;

import net.mcreator.quantumdimensions.init.QuantumDimensionsModMenus;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2668;
import net.minecraft.class_2673;
import net.minecraft.class_2696;
import net.minecraft.class_2783;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.mcreator.quantumdimensions.init.QuantumDimensionsModItems;

import java.util.Set;

public class QuantumMachineProcedureProcedure {
	public static boolean eventResult = true;

	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity) {
		if (entity == null)
			return;
		class_1799 item = class_1799.field_8037;
		item = (entity instanceof class_1657 _plrSlotItem && _plrSlotItem.field_7512 instanceof QuantumDimensionsModMenus.MenuAccessor _menu0 ? _menu0.getSlots().get(0).method_7677() : class_1799.field_8037).method_7972();
		if (entity instanceof class_1657 _player && _player.field_7512 instanceof QuantumDimensionsModMenus.MenuAccessor _menu) {
			_menu.getSlots().get(0).method_7673(class_1799.field_8037);
			_player.field_7512.method_7623();
		}
		if (class_2246.field_10566.method_8389() == item.method_7909()) {
			if (entity instanceof class_3222 _player && _player.method_51469() instanceof class_3218 _serverLevel) {
				class_5321<class_1937> destinationType3 = class_1937.field_25179;
				if (_player.method_51469().method_27983() == destinationType3)
					return;
				class_3218 nextLevel3 = _serverLevel.method_8503().method_3847(destinationType3);
				if (nextLevel3 != null) {
					_player.field_13987.method_14364(new class_2668(class_2668.field_25649, 0));
					_player.method_48105(nextLevel3, _player.method_23317(), _player.method_23318(), _player.method_23321(), Set.of(), _player.method_36454(), _player.method_36455(), true);
					_player.field_13987.method_14364(new class_2696(_player.method_31549()));
					for (class_1293 _effectinstance : _player.method_6026())
						_player.field_13987.method_14364(new class_2783(_player.method_5628(), _effectinstance, false));
					_player.field_13987.method_14364(new class_2673(1032, class_2338.field_10980, 0, false));
				}
			}
		} else if (class_2246.field_10515.method_8389() == item.method_7909()) {
			if (entity instanceof class_3222 _player && _player.method_51469() instanceof class_3218 _serverLevel) {
				class_5321<class_1937> destinationType5 = class_1937.field_25180;
				if (_player.method_51469().method_27983() == destinationType5)
					return;
				class_3218 nextLevel5 = _serverLevel.method_8503().method_3847(destinationType5);
				if (nextLevel5 != null) {
					_player.field_13987.method_14364(new class_2668(class_2668.field_25649, 0));
					_player.method_48105(nextLevel5, _player.method_23317(), _player.method_23318(), _player.method_23321(), Set.of(), _player.method_36454(), _player.method_36455(), true);
					_player.field_13987.method_14364(new class_2696(_player.method_31549()));
					for (class_1293 _effectinstance : _player.method_6026())
						_player.field_13987.method_14364(new class_2783(_player.method_5628(), _effectinstance, false));
					_player.field_13987.method_14364(new class_2673(1032, class_2338.field_10980, 0, false));
				}
			}
		} else if (class_2246.field_10471.method_8389() == item.method_7909()) {
			if (entity instanceof class_3222 _player && _player.method_51469() instanceof class_3218 _serverLevel) {
				class_5321<class_1937> destinationType7 = class_1937.field_25181;
				if (_player.method_51469().method_27983() == destinationType7)
					return;
				class_3218 nextLevel7 = _serverLevel.method_8503().method_3847(destinationType7);
				if (nextLevel7 != null) {
					_player.field_13987.method_14364(new class_2668(class_2668.field_25649, 0));
					_player.method_48105(nextLevel7, _player.method_23317(), _player.method_23318(), _player.method_23321(), Set.of(), _player.method_36454(), _player.method_36455(), true);
					_player.field_13987.method_14364(new class_2696(_player.method_31549()));
					for (class_1293 _effectinstance : _player.method_6026())
						_player.field_13987.method_14364(new class_2783(_player.method_5628(), _effectinstance, false));
					_player.field_13987.method_14364(new class_2673(1032, class_2338.field_10980, 0, false));
				}
			}
		} else if (QuantumDimensionsModItems.TESSERACT == item.method_7909()) {
			if (entity instanceof class_3222 _player && _player.method_51469() instanceof class_3218 _serverLevel) {
				class_5321<class_1937> destinationType9 = class_5321.method_29179(class_7924.field_41223, class_2960.method_60654("quantum_dimensions:the_27th_dimension"));
				if (_player.method_51469().method_27983() == destinationType9)
					return;
				class_3218 nextLevel9 = _serverLevel.method_8503().method_3847(destinationType9);
				if (nextLevel9 != null) {
					_player.field_13987.method_14364(new class_2668(class_2668.field_25649, 0));
					_player.method_48105(nextLevel9, _player.method_23317(), _player.method_23318(), _player.method_23321(), Set.of(), _player.method_36454(), _player.method_36455(), true);
					_player.field_13987.method_14364(new class_2696(_player.method_31549()));
					for (class_1293 _effectinstance : _player.method_6026())
						_player.field_13987.method_14364(new class_2783(_player.method_5628(), _effectinstance, false));
					_player.field_13987.method_14364(new class_2673(1032, class_2338.field_10980, 0, false));
				}
			}
		} else {
			if (world instanceof class_3218 _level) {
				_level.method_8503().method_3734().method_44252(new class_2168(class_2165.field_17395, new class_243(x, y, z), class_241.field_1340, _level, 4, "", class_2561.method_43470(""), _level.method_8503(), null).method_9217(),
						"summon minecraft:lightning_bolt");
			}
		}
		if (entity instanceof class_1657 _player) {
			_player.field_7512 = _player.field_7498;
		}
	}
}
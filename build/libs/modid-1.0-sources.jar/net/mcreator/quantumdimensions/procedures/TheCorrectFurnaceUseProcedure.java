package net.mcreator.quantumdimensions.procedures;

import net.mcreator.quantumdimensions.init.QuantumDimensionsModItems;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_167;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8779;

public class TheCorrectFurnaceUseProcedure {
	public static boolean eventResult = true;

	public static void execute(class_1936 world, double x, double y, double z, class_1297 entity) {
		if (entity == null)
			return;
		world.method_8652(class_2338.method_49637(x, y, z), class_2246.field_10124.method_9564(), 3);
		if (world instanceof class_1937 _level && !_level.method_8608()) {
			_level.method_8437(null, x, y, z, 4, class_1937.class_7867.field_40889);
		}
		if (world instanceof class_3218 _level) {
			class_1542 entityToSpawn_2 = new class_1542(_level, x, y, z, new class_1799(QuantumDimensionsModItems.TESSERACT));
			entityToSpawn_2.method_6982(10);
			entityToSpawn_2.method_35190();
			_level.method_8649(entityToSpawn_2);
		}
		if (entity instanceof class_3222 _player && _player.method_51469() instanceof class_3218 _level) {
			class_8779 _adv3 = _level.method_8503().method_3851().method_12896(class_2960.method_60654("quantum_dimensions:get_the_correct_furnace"));
			if (_adv3 != null) {
				class_167 _ap = _player.method_14236().method_12882(_adv3);
				if (!_ap.method_740()) {
					for (String criteria : _ap.method_731())
						_player.method_14236().method_12878(_adv3, criteria);
				}
			}
		}
	}
}
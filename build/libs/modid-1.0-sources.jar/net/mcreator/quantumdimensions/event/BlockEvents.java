package net.mcreator.quantumdimensions.event;

import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.fabricmc.fabric.api.event.Event;

public class BlockEvents {
	public static final Event<BlockMultiplace> BLOCK_MULTIPLACE = EventFactory.createArrayBacked(BlockMultiplace.class, (callbacks) -> (position, entity, placed, placedAgainst) -> {
		for (BlockMultiplace event : callbacks) {
			boolean result = event.onMultiplaced(position, entity, placed, placedAgainst);
			if (!result) {
				return false;
			}
		}
		return true;
	});
	public static final Event<BlockPlace> BLOCK_PLACE = EventFactory.createArrayBacked(BlockPlace.class, (callbacks) -> (position, entity, placed, placedAgainst) -> {
		for (BlockPlace event : callbacks) {
			boolean result = event.onBlockPlaced(position, entity, placed, placedAgainst);
			if (!result) {
				return false;
			}
		}
		return true;
	});

	@FunctionalInterface
	public interface BlockMultiplace {
		boolean onMultiplaced(class_2338 position, class_1297 entity, class_2680 placed, class_2680 placedAgainst);
	}

	@FunctionalInterface
	public interface BlockPlace {
		boolean onBlockPlaced(class_2338 position, class_1297 entity, class_2680 placed, class_2680 placedAgainst);
	}
}
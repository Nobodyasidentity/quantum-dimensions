package net.mcreator.quantumdimensions.block;

import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_4970;

public class CompactDiamondBlockBlock extends class_2248 {
	public CompactDiamondBlockBlock(class_4970.class_2251 properties) {
		super(properties.method_9626(class_2498.field_11533).method_9629(5f, 10f).method_26247((bs, br, bp) -> true).method_26249((bs, br, bp) -> true).method_51368(class_2766.field_18284));
	}

	@Override
	public int method_9505(class_2680 state) {
		return 15;
	}
}
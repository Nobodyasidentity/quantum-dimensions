package net.mcreator.quantumdimensions.block.entity;

import org.jetbrains.annotations.Nullable;
import net.mcreator.quantumdimensions.world.inventory.QuantumMachineGUIMenu;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1278;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2621;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.mcreator.quantumdimensions.init.QuantumDimensionsModBlockEntities;

import java.util.stream.IntStream;

import io.netty.buffer.Unpooled;

public class QuantumMachineBlockEntity extends class_2621 implements class_1278 {
	private class_2371<class_1799> stacks = class_2371.method_10213(9, class_1799.field_8037);

	public QuantumMachineBlockEntity(class_2338 position, class_2680 state) {
		super(QuantumDimensionsModBlockEntities.QUANTUM_MACHINE, position, state);
	}

	@Override
	public void method_11014(class_11368 valueInput) {
		super.method_11014(valueInput);
		if (!this.method_54871(valueInput))
			this.stacks = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
		class_1262.method_5429(valueInput, this.stacks);
	}

	@Override
	public void method_11007(class_11372 valueOutput) {
		super.method_11007(valueOutput);
		if (!this.method_54872(valueOutput))
			class_1262.method_5426(valueOutput, this.stacks);
	}

	@Override
	public class_2622 method_38235() {
		return class_2622.method_38585(this);
	}

	@Override
	public class_2487 method_16887(class_7225.class_7874 lookupProvider) {
		return this.method_38242(lookupProvider);
	}

	@Override
	public int method_5439() {
		return stacks.size();
	}

	@Override
	public boolean method_5442() {
		for (class_1799 itemstack : this.stacks)
			if (!itemstack.method_7960())
				return false;
		return true;
	}

	@Override
	public class_2561 method_17823() {
		return class_2561.method_43470("quantum_machine");
	}

	@Override
	public int method_5444() {
		return 1;
	}

	@Override
	public class_1703 method_5465(int id, class_1661 inventory) {
		return new QuantumMachineGUIMenu(id, inventory, this, new class_2540(Unpooled.buffer()).method_10807(this.field_11867));
	}

	@Override
	public class_2561 method_5476() {
		return class_2561.method_43470("Quantum Machine");
	}

	@Override
	protected class_2371<class_1799> method_11282() {
		return this.stacks;
	}

	@Override
	protected void method_11281(class_2371<class_1799> stacks) {
		this.stacks = stacks;
	}

	@Override
	public boolean method_5437(int index, class_1799 stack) {
		return true;
	}

	@Override
	public int[] method_5494(class_2350 side) {
		return IntStream.range(0, this.method_5439()).toArray();
	}

	@Override
	public boolean method_5492(int index, class_1799 itemstack, @Nullable class_2350 direction) {
		return this.method_5437(index, itemstack);
	}

	@Override
	public boolean method_5493(int index, class_1799 itemstack, class_2350 direction) {
		return true;
	}
}
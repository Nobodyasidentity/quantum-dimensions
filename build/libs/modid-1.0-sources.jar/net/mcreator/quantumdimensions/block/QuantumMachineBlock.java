package net.mcreator.quantumdimensions.block;

import net.mcreator.quantumdimensions.block.entity.QuantumMachineBlockEntity;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2766;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4970;

public class QuantumMachineBlock extends class_2248 implements class_2343 {
	public QuantumMachineBlock(class_4970.class_2251 properties) {
		super(properties.method_9626(class_2498.field_11531).method_9629(5f, 10f).method_51368(class_2766.field_18284));
	}

	@Override
	public int method_9505(class_2680 state) {
		return 15;
	}

	@Override
	public class_1269 method_55766(class_2680 blockstate, class_1937 world, class_2338 pos, class_1657 entity, class_3965 hit) {
		super.method_55766(blockstate, world, pos, entity, hit);
		if (entity instanceof class_3222 player) {
			class_2586 tileEntity = world.method_8321(pos);
			player.method_17355(tileEntity instanceof class_3908 menuProvider ? menuProvider : null);
		}
		return class_1269.field_5812;
	}

	@Override
	public class_3908 method_17454(class_2680 state, class_1937 worldIn, class_2338 pos) {
		class_2586 tileEntity = worldIn.method_8321(pos);
		return tileEntity instanceof class_3908 menuProvider ? menuProvider : null;
	}

	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new QuantumMachineBlockEntity(pos, state);
	}

	@Override
	public boolean method_9592(class_2680 state, class_1937 world, class_2338 pos, int eventID, int eventParam) {
		super.method_9592(state, world, pos, eventID, eventParam);
		class_2586 blockEntity = world.method_8321(pos);
		return blockEntity != null && blockEntity.method_11004(eventID, eventParam);
	}

	@Override
	protected void method_66388(class_2680 blockstate, class_3218 world, class_2338 blockpos, boolean flag) {
		class_1264.method_66221(blockstate, world, blockpos);
	}

	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}

	@Override
	public int method_9572(class_2680 blockState, class_1937 world, class_2338 pos) {
		class_2586 tileentity = world.method_8321(pos);
		if (tileentity instanceof QuantumMachineBlockEntity be)
			return class_1703.method_7618(be);
		else
			return 0;
	}
}
package net.mcreator.quantumdimensions.block;

import net.mcreator.quantumdimensions.procedures.TheCorrectFurnaceUseProcedure;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_2766;
import net.minecraft.class_3965;
import net.minecraft.class_4970;

public class TheCorrectFurnaceBlock extends class_2248 {
	public static final class_2754<class_2350> FACING = class_2383.field_11177;

	public TheCorrectFurnaceBlock(class_4970.class_2251 properties) {
		super(properties.method_9632(3.5f).method_51368(class_2766.field_12653));
		this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
	}

	@Override
	public int method_9505(class_2680 state) {
		return 15;
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		super.method_9515(builder);
		builder.method_11667(FACING);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		return super.method_9605(context).method_11657(FACING, context.method_8042().method_10153());
	}

	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		return state.method_11657(FACING, rot.method_10503(state.method_11654(FACING)));
	}

	public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
		return state.method_26186(mirrorIn.method_10345(state.method_11654(FACING)));
	}

	@Override
	public class_1269 method_55766(class_2680 blockstate, class_1937 world, class_2338 pos, class_1657 entity, class_3965 hit) {
		super.method_55766(blockstate, world, pos, entity, hit);
		int x = pos.method_10263();
		int y = pos.method_10264();
		int z = pos.method_10260();
		double hitX = hit.method_17784().field_1352;
		double hitY = hit.method_17784().field_1351;
		double hitZ = hit.method_17784().field_1350;
		class_2350 direction = hit.method_17780();
		TheCorrectFurnaceUseProcedure.execute(world, x, y, z, entity);
		return class_1269.field_5812;
	}
}
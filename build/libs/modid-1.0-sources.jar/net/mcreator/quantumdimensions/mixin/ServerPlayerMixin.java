package net.mcreator.quantumdimensions.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3222.class)
public abstract class ServerPlayerMixin {
	@Inject(method = "Lnet/minecraft/server/level/ServerPlayer;drop(Z)Z", at = @At("HEAD"), cancellable = true)
	public void drop(boolean dropStack, CallbackInfoReturnable<Boolean> cir) {
		class_3222 self = (class_3222) (Object) this;
		class_1661 inventory = self.method_31548();
		class_1799 itemstack = inventory.method_37417(dropStack);
		self.field_7512.method_37418(inventory, inventory.method_67532()).ifPresent(p_401732_ -> self.field_7512.method_34245(p_401732_, inventory.method_7391()));
		cir.setReturnValue(self.method_7329(itemstack, false, true) != null);
	}
}
package net.mcreator.quantumdimensions.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Mixin;
import net.mcreator.quantumdimensions.event.LivingEntityEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_3218;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {
	@Shadow
	protected int lastHurtByPlayerMemoryTime;

	@Shadow
	protected boolean isAlwaysExperienceDropper() {
		return false;
	}

	@Inject(method = "swing(Lnet/minecraft/world/InteractionHand;Z)V", at = @At("HEAD"))
	public void swing(class_1268 hand, boolean updateSelf, CallbackInfo ci) {
		class_1799 stack = ((class_1309) (Object) this).method_5998(hand);
		if (!stack.method_7960()) {
		}
	}

	@Inject(method = "startUsingItem(Lnet/minecraft/world/InteractionHand;)V", at = @At("HEAD"))
	public void startUsingItem(class_1268 hand, CallbackInfo ci) {
		class_1309 entity = (class_1309) (Object) this;
		class_1799 stack = entity.method_5998(hand);
		if (!stack.method_7960() && !entity.method_6115()) {
			LivingEntityEvents.START_USE_ITEM.invoker().onStartUseItem(entity, stack);
		}
	}

	@Inject(method = "heal(F)V", at = @At("HEAD"), cancellable = true)
	public void heal(float amount, CallbackInfo ci) {
		if (!LivingEntityEvents.ENTITY_HEAL.invoker().onEntityHeal((class_1309) (Object) this, amount))
			ci.cancel();
	}

	@Inject(method = "applyItemBlocking(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)F", at = @At("HEAD"), cancellable = true)
	public void applyItemBlocking(class_3218 serverLevel, class_1282 damageSource, float f, CallbackInfoReturnable<Float> cir) {
		if (!LivingEntityEvents.ENTITY_BLOCK.invoker().onEntityBlock((class_1309) (Object) this, damageSource, (double) f))
			cir.cancel();
	}

	@Inject(method = "dropExperience(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/Entity;)V", at = @At("HEAD"), cancellable = true)
	public void dropExperience(class_3218 serverLevel, class_1297 entity, CallbackInfo ci) {
		class_1309 self = (class_1309) (Object) this;
		if (!self.method_41330() && (this.isAlwaysExperienceDropper() || this.lastHurtByPlayerMemoryTime > 0 && self.method_6054() && serverLevel.method_64395().method_8355(class_1928.field_19391))) {
			if (!LivingEntityEvents.ENTITY_DROP_XP.invoker().onEntityDropXp(self, self.method_66280(), (double) self.method_59923(serverLevel, entity)))
				ci.cancel();
		}
	}

	@Inject(method = "causeFallDamage(DFLnet/minecraft/world/damagesource/DamageSource;)Z", at = @At("HEAD"), cancellable = true)
	public void causeFallDamage(double d, float f, class_1282 damageSource, CallbackInfoReturnable<Boolean> cir) {
		if (!LivingEntityEvents.ENTITY_FALL.invoker().onEntityFall((class_1309) (Object) this, d, (double) f))
			cir.setReturnValue(false);
	}

	@Inject(method = "onItemPickup(Lnet/minecraft/world/entity/item/ItemEntity;)V", at = @At("HEAD"))
	public void onItemPickup(class_1542 itemEntity, CallbackInfo ci) {
		LivingEntityEvents.ENTITY_PICKUP_ITEM.invoker().onEntityPickupItem(itemEntity.method_24921(), itemEntity.method_6983());
	}

	@Inject(method = "jumpFromGround()V", at = @At("TAIL"))
	public void jumpFromGround(CallbackInfo ci) {
		LivingEntityEvents.ENTITY_JUMP.invoker().onEntityJump((class_1309) (Object) this);
	}
}
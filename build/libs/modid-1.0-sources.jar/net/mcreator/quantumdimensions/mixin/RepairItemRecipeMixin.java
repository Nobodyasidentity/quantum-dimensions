package net.mcreator.quantumdimensions.mixin;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;
import java.util.ArrayList;
import net.minecraft.class_1799;
import net.minecraft.class_4317;
import net.minecraft.class_7225;
import net.minecraft.class_9694;
import com.google.common.collect.Lists;

@Mixin(class_4317.class)
public abstract class RepairItemRecipeMixin {
	@Inject(method = "assemble(Lnet/minecraft/world/item/crafting/CraftingInput;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/world/item/ItemStack;", at = @At("HEAD"), cancellable = true)
	public void assemble(class_9694 craftingInput, class_7225.class_7874 provider, CallbackInfoReturnable<class_1799> cir) {
		class_1799 itemStack3;
		class_1799 itemStack;
		ArrayList<class_1799> list = Lists.newArrayList();
		for (int i = 0; i < craftingInput.method_59990(); ++i) {
			class_1799 itemStack2;
			itemStack = craftingInput.method_59984(i);
			if (itemStack.method_7960())
				continue;
			list.add(itemStack);
		}
	}
}
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.quantumdimensions.init;

import net.mcreator.quantumdimensions.QuantumDimensionsMod;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class QuantumDimensionsModTabs {
	public static class_5321<class_1761> TAB_QUANTUM_DIMENSIONS = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(QuantumDimensionsMod.MODID, "quantum_dimensions"));

	public static void load() {
		class_2378.method_39197(class_7923.field_44687, TAB_QUANTUM_DIMENSIONS,
				FabricItemGroup.builder().method_47321(class_2561.method_43471("item_group.quantum_dimensions.quantum_dimensions")).method_47320(() -> new class_1799(QuantumDimensionsModItems.TESSERACT)).method_47317((parameters, tabData) -> {
					tabData.method_45421(QuantumDimensionsModBlocks.COMPACT_DIAMOND_BLOCK.method_8389());
					tabData.method_45421(QuantumDimensionsModItems.TESSERACT);
					tabData.method_45421(QuantumDimensionsModBlocks.QUANTUM_MACHINE.method_8389());
					tabData.method_45421(QuantumDimensionsModItems.REBREATHER);
					tabData.method_45421(QuantumDimensionsModBlocks.THE_CORRECT_FURNACE.method_8389());
					tabData.method_45421(QuantumDimensionsModItems.QUANTUM_ERASER);
				}).method_47324());
	}
}
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.quantumdimensions.init;

import net.mcreator.quantumdimensions.block.entity.QuantumMachineBlockEntity;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.mcreator.quantumdimensions.QuantumDimensionsMod;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

public class QuantumDimensionsModBlockEntities {
	public static class_2591<QuantumMachineBlockEntity> QUANTUM_MACHINE;

	public static void load() {
		QUANTUM_MACHINE = register("quantum_machine", QuantumDimensionsModBlocks.QUANTUM_MACHINE, QuantumMachineBlockEntity::new);
	}

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static <T extends class_2586> class_2591<T> register(String registryname, class_2248 block, FabricBlockEntityTypeBuilder.Factory<? extends T> supplier) {
		return class_2378.method_10230(class_7923.field_41181, class_2960.method_60655(QuantumDimensionsMod.MODID, registryname), FabricBlockEntityTypeBuilder.<T>create(supplier, block).build());
	}
}
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.quantumdimensions.init;

import net.mcreator.quantumdimensions.block.TheCorrectFurnaceBlock;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.mcreator.quantumdimensions.block.QuantumMachineBlock;
import net.mcreator.quantumdimensions.block.CompactDiamondBlockBlock;
import net.mcreator.quantumdimensions.QuantumDimensionsMod;

import java.util.function.Function;

public class QuantumDimensionsModBlocks {
	public static class_2248 COMPACT_DIAMOND_BLOCK;
	public static class_2248 QUANTUM_MACHINE;
	public static class_2248 THE_CORRECT_FURNACE;

	public static void load() {
		COMPACT_DIAMOND_BLOCK = register("compact_diamond_block", CompactDiamondBlockBlock::new);
		QUANTUM_MACHINE = register("quantum_machine", QuantumMachineBlock::new);
		THE_CORRECT_FURNACE = register("the_correct_furnace", TheCorrectFurnaceBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends class_2248> B register(String name, Function<class_4970.class_2251, B> supplier) {
		return (B) class_2246.method_63053(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(QuantumDimensionsMod.MODID, name)), (Function<class_4970.class_2251, class_2248>) supplier, class_4970.class_2251.method_9637());
	}
}
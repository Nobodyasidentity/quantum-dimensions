/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.quantumdimensions.init;

import net.mcreator.quantumdimensions.item.TesseractItem;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1814;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.mcreator.quantumdimensions.item.RebreatherItem;
import net.mcreator.quantumdimensions.item.QuantumEraserItem;
import net.mcreator.quantumdimensions.QuantumDimensionsMod;

import java.util.function.Function;

public class QuantumDimensionsModItems {
	public static class_1792 COMPACT_DIAMOND_BLOCK;
	public static class_1792 TESSERACT;
	public static class_1792 QUANTUM_MACHINE;
	public static class_1792 REBREATHER;
	public static class_1792 THE_CORRECT_FURNACE;
	public static class_1792 QUANTUM_ERASER;

	public static void load() {
		COMPACT_DIAMOND_BLOCK = block(QuantumDimensionsModBlocks.COMPACT_DIAMOND_BLOCK, "compact_diamond_block", new class_1792.class_1793().method_7894(class_1814.field_8904).method_24359());
		TESSERACT = register("tesseract", TesseractItem::new);
		QUANTUM_MACHINE = block(QuantumDimensionsModBlocks.QUANTUM_MACHINE, "quantum_machine", new class_1792.class_1793().method_7894(class_1814.field_8904).method_24359());
		REBREATHER = register("rebreather", RebreatherItem::new);
		THE_CORRECT_FURNACE = block(QuantumDimensionsModBlocks.THE_CORRECT_FURNACE, "the_correct_furnace");
		QUANTUM_ERASER = register("quantum_eraser", QuantumEraserItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends class_1792> I register(String name, Function<class_1792.class_1793, ? extends I> supplier) {
		return (I) class_1802.method_63747(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(QuantumDimensionsMod.MODID, name)), (Function<class_1792.class_1793, class_1792>) supplier);
	}

	private static class_1792 block(class_2248 block, String name) {
		return block(block, name, new class_1792.class_1793());
	}

	private static class_1792 block(class_2248 block, String name, class_1792.class_1793 properties) {
		return class_1802.method_51348(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(QuantumDimensionsMod.MODID, name)), prop -> new class_1747(block, prop), properties);
	}
}
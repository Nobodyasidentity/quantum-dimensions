package net.mcreator.quantumdimensions.world.dimension;

import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_5294;

public class The27thDimensionDimension {
	public static void load() {
		class_5294 customEffect = new class_5294(class_5294.class_5401.field_25640, false, false) {
			@Override
			public class_243 method_28112(class_243 color, float sunHeight) {
				return color.method_18805(sunHeight * 0.94 + 0.06, sunHeight * 0.94 + 0.06, sunHeight * 0.91 + 0.09);
			}

			@Override
			public boolean method_28110(int x, int y) {
				return false;
			}
		};
		DimensionRenderingRegistry.registerDimensionEffects(class_2960.method_60654("quantum_dimensions:the_27th_dimension"), customEffect);
	}
}
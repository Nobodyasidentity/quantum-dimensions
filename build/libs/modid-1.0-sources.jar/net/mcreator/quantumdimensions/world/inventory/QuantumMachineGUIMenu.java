package net.mcreator.quantumdimensions.world.inventory;

import net.mcreator.quantumdimensions.network.QuantumMachineGUIButtonMessage;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_3914;
import net.mcreator.quantumdimensions.init.QuantumDimensionsModMenus;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

import java.util.function.Supplier;
import java.util.Map;
import java.util.HashMap;
import java.util.Collections;

public class QuantumMachineGUIMenu extends class_1703 implements QuantumDimensionsModMenus.MenuAccessor {
	public final Map<String, Object> menuState = new HashMap<>() {
		@Override
		public Object put(String key, Object value) {
			if (!this.containsKey(key) && this.size() >= 3)
				return null;
			return super.put(key, value);
		}
	};
	public final class_1937 world;
	public final class_1657 entity;
	public int x, y, z;
	private class_3914 access = class_3914.field_17304;
	private final class_1263 inventory;
	private final Map<Integer, class_1735> customSlots = new HashMap<>();
	private boolean bound = false;
	private Supplier<Boolean> boundItemMatcher = null;
	private class_1799 boundItem = null;

	public QuantumMachineGUIMenu(int id, class_1661 inv) {
		this(id, inv, new class_1277(1));
		this.x = (int) inv.field_7546.method_23317();
		this.y = (int) inv.field_7546.method_23318();
		this.z = (int) inv.field_7546.method_23321();
		access = class_3914.method_17392(inv.field_7546.method_37908(), new class_2338(x, y, z));
	}

	public QuantumMachineGUIMenu(int id, class_1661 inv, class_2540 extraData) {
		this(id, inv, new class_1277(1), extraData);
	}

	public QuantumMachineGUIMenu(int id, class_1661 inv, class_1263 container, class_2540 extraData) {
		this(id, inv, container);
		class_2338 pos = null;
		if (extraData != null) {
			pos = extraData.method_10811();
			this.x = pos.method_10263();
			this.y = pos.method_10264();
			this.z = pos.method_10260();
			access = class_3914.method_17392(world, pos);
		}
		if (pos != null) {
			if (extraData.readableBytes() == 1) { // bound to item
				byte hand = extraData.readByte();
				class_1799 itemstack = hand == 0 ? this.entity.method_6047() : this.entity.method_6079();
				this.boundItem = itemstack;
				this.boundItemMatcher = () -> itemstack == (hand == 0 ? this.entity.method_6047() : this.entity.method_6079());
				this.bound = true;
			}
		}
	}

	public QuantumMachineGUIMenu(int id, class_1661 inv, class_1263 container) {
		super(QuantumDimensionsModMenus.QUANTUM_MACHINE_GUI, id);
		this.entity = inv.field_7546;
		this.world = inv.field_7546.method_37908();
		this.inventory = container;
		this.customSlots.put(0, this.method_7621(new class_1735(inventory, 0, 79, 26) {
			private final int slot = 0;
			private int x = QuantumMachineGUIMenu.this.x;
			private int y = QuantumMachineGUIMenu.this.y;
		}));
		for (int si = 0; si < 3; ++si)
			for (int sj = 0; sj < 9; ++sj)
				this.method_7621(new class_1735(inv, sj + (si + 1) * 9, 0 + 8 + sj * 18, 0 + 84 + si * 18));
		for (int si = 0; si < 9; ++si)
			this.method_7621(new class_1735(inv, si, 0 + 8 + si * 18, 0 + 142));
	}

	@Override
	public boolean method_7597(class_1657 player) {
		if (this.bound) {
			if (this.boundItemMatcher != null)
				return this.boundItemMatcher.get();
		}
		return this.inventory.method_5443(player);
	}

	@Override
	public class_1799 method_7601(class_1657 playerIn, int index) {
		class_1799 itemstack = class_1799.field_8037;
		class_1735 slot = (class_1735) this.field_7761.get(index);
		if (slot != null && slot.method_7681()) {
			class_1799 itemstack1 = slot.method_7677();
			itemstack = itemstack1.method_7972();
			if (index < 1) {
				if (!this.method_7616(itemstack1, 1, this.field_7761.size(), true))
					return class_1799.field_8037;
				slot.method_7670(itemstack1, itemstack);
			} else if (boundItem != null && itemstack1 == boundItem) {
				return class_1799.field_8037;
			} else if (!this.method_7616(itemstack1, 0, 1, false)) {
				if (index < 1 + 27) {
					if (!this.method_7616(itemstack1, 1 + 27, this.field_7761.size(), true))
						return class_1799.field_8037;
				} else {
					if (!this.method_7616(itemstack1, 1, 1 + 27, false))
						return class_1799.field_8037;
				}
				return class_1799.field_8037;
			}
			if (itemstack1.method_7960()) {
				slot.method_53512(class_1799.field_8037);
			} else {
				slot.method_7668();
			}
			if (itemstack1.method_7947() == itemstack.method_7947()) {
				return class_1799.field_8037;
			}
			slot.method_7667(playerIn, itemstack1);
		}
		return itemstack;
	}

	@Override
	public void method_7593(int slotId, int button, class_1713 clickType, class_1657 player) {
		if (clickType == class_1713.field_7791 && boundItem != null) {
			if (slotId >= 0 && slotId < this.field_7761.size()) {
				class_1799 slotItem = this.field_7761.get(slotId).method_7677();
				class_1799 hotbarItem = player.method_31548().method_5438(button);
				if (slotItem == boundItem || hotbarItem == boundItem) {
					return;
				}
			}
		}
		super.method_7593(slotId, button, clickType, player);
	}

	@Override
	protected boolean method_7616(class_1799 itemstack, int i, int j, boolean bl) {
		int l;
		class_1799 itemstack2;
		class_1735 slot;
		boolean bl2 = false;
		int k = i;
		if (bl) {
			k = j - 1;
		}
		if (itemstack.method_7946()) {
			while (!itemstack.method_7960() && (bl ? k >= i : k < j)) {
				slot = this.field_7761.get(k);
				itemstack2 = slot.method_7677();
				if (!itemstack2.method_7960() && class_1799.method_31577(itemstack, itemstack2)) {
					int m;
					l = itemstack2.method_7947() + itemstack.method_7947();
					if (l <= (m = slot.method_7676(itemstack2))) {
						itemstack.method_7939(0);
						itemstack2.method_7939(l);
						slot.method_7673(itemstack2);
						bl2 = true;
					} else if (itemstack2.method_7947() < m) {
						itemstack.method_7934(m - itemstack2.method_7947());
						itemstack2.method_7939(m);
						slot.method_7673(itemstack2);
						bl2 = true;
					}
				}
				if (bl) {
					--k;
					continue;
				}
				++k;
			}
		}
		if (!itemstack.method_7960()) {
			k = bl ? j - 1 : i;
			while (bl ? k >= i : k < j) {
				slot = this.field_7761.get(k);
				itemstack2 = slot.method_7677();
				if (itemstack2.method_7960() && slot.method_7680(itemstack)) {
					l = slot.method_7676(itemstack);
					slot.method_53512(itemstack.method_7971(Math.min(itemstack.method_7947(), l)));
					bl2 = true;
					break;
				}
				if (bl) {
					--k;
					continue;
				}
				++k;
			}
		}
		return bl2;
	}

	@Override
	public void method_7595(class_1657 playerIn) {
		super.method_7595(playerIn);
	}

	@Override
	public Map<Integer, class_1735> getSlots() {
		return Collections.unmodifiableMap(customSlots);
	}

	@Override
	public Map<String, Object> getMenuState() {
		return menuState;
	}

	public static void screenInit() {
		PayloadTypeRegistry.playC2S().register(QuantumMachineGUIButtonMessage.TYPE, QuantumMachineGUIButtonMessage.STREAM_CODEC);
		ServerPlayNetworking.registerGlobalReceiver(QuantumMachineGUIButtonMessage.TYPE, QuantumMachineGUIButtonMessage::handleData);
	}
}
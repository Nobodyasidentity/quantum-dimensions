package net.mcreator.quantumdimensions.client.gui;

import net.mcreator.quantumdimensions.world.inventory.QuantumMachineGUIMenu;
import net.minecraft.class_10799;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.mcreator.quantumdimensions.network.QuantumMachineGUIButtonMessage;
import net.mcreator.quantumdimensions.init.QuantumDimensionsModScreens;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class QuantumMachineGUIScreen extends class_465<QuantumMachineGUIMenu> implements QuantumDimensionsModScreens.FabricScreenAccessor {
	private final class_1937 world;
	private final int x, y, z;
	private final class_1657 entity;
	private boolean menuStateUpdateActive = false;
	private class_4185 button_teleport;
	private static final class_2960 BACKGROUND = class_2960.method_60654("quantum_dimensions:textures/screens/quantum_machine_gui.png");

	public QuantumMachineGUIScreen(QuantumMachineGUIMenu container, class_1661 inventory, class_2561 text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.field_2792 = 176;
		this.field_2779 = 166;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.method_25394(guiGraphics, mouseX, mouseY, partialTicks);
		this.method_2380(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void method_2389(class_332 guiGraphics, float partialTicks, int mouseX, int mouseY) {
		guiGraphics.method_25290(class_10799.field_56883, BACKGROUND, this.field_2776, this.field_2800, 0, 0, this.field_2792, this.field_2779, this.field_2792, this.field_2779);
	}

	@Override
	public boolean method_25404(int key, int b, int c) {
		if (key == 256) {
			this.field_22787.field_1724.method_7346();
			return true;
		}
		return super.method_25404(key, b, c);
	}

	@Override
	protected void method_2388(class_332 guiGraphics, int mouseX, int mouseY) {
		guiGraphics.method_51439(this.field_22793, class_2561.method_43471("gui.quantum_dimensions.quantum_machine_gui.label_quantum_machine"), 51, 7, -1, true);
	}

	@Override
	public void method_25426() {
		super.method_25426();
		button_teleport = class_4185.method_46430(class_2561.method_43471("gui.quantum_dimensions.quantum_machine_gui.button_teleport"), e -> {
			int x = QuantumMachineGUIScreen.this.x;
			int y = QuantumMachineGUIScreen.this.y;
			if (true) {
				ClientPlayNetworking.send(new QuantumMachineGUIButtonMessage(0, x, y, z));
				QuantumMachineGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).method_46434(this.field_2776 + 55, this.field_2800 + 53, 65, 20).method_46431();
		this.method_37063(button_teleport);
	}
}